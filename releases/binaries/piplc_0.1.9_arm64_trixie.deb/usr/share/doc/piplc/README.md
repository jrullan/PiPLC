# PiPLC - Raspberry Pi Soft-PLC

A full-featured software PLC for Raspberry Pi and single-board computers, featuring a Qt-based ladder logic editor with drag-and-drop programming, virtual I/O simulation, and GPIO integration.

## Features

- **Visual Ladder Editor** — Drag-and-drop programming with 30 instruction types, parallel branches, undo/redo
- **Contact Decorators** — Layer timers, counters, one-shots, and debounce filters directly on contacts
- **Multi-Context Engines** — Up to 8 independent PLC contexts with inter-context signal routing
- **Remote Deployment** — Headless engine server for Raspberry Pi with WebSocket-based editor connection
- **Virtual I/O Simulation** — Test programs without hardware using the simulation panel
- **GPIO Integration** — libgpiod-based hardware I/O with configurable pin mapping
- **Cross-Platform** — Windows, Linux x64, and ARM64 (Raspberry Pi)

## Quick Start

```bash
cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
./build/bin/PiPLC
```

## Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](docs/getting-started.md) | Installation, deployment modes, and testing |
| [Building from Source](docs/building.md) | Build instructions for all platforms |
| **Architecture** | |
| [Architecture Overview](docs/architecture/overview.md) | System design, layers, and components |
| [Threading Model](docs/architecture/threading.md) | Multi-threaded architecture and thread safety |
| [WebSocket Protocol](docs/architecture/protocol.md) | Editor-engine communication protocol |
| [GPIO Architecture](docs/architecture/gpio.md) | Hardware I/O integration with libgpiod |
| **Reference** | |
| [Instruction Reference](docs/reference/instructions.md) | All 30 ladder logic instructions |
| [Decorator Guide](docs/reference/decorators.md) | Contact decorator usage and chaining |
| [Memory Regions](docs/reference/memory-regions.md) | PLC memory organization and addressing |
| [File Formats](docs/reference/file-formats.md) | .plcproj, .mplcproj, .ioconfig, CSV formats |
| **Schema** | |
| [XML Schema v3.0](docs/schema/PLCProject-v3.0.md) | Project file format specification |
| [Versioning Strategy](docs/schema/VERSIONING.md) | Schema versioning and migration |

## Project Structure

```
PiPLC/
├── src/
│   ├── app/              # Application shell (MainWindow, ActionManager)
│   ├── core/             # piplc-core static library (model + runtime, QtCore-only)
│   ├── editor/           # Ladder editor widgets and graphics items
│   │   ├── commands/     # Undo/redo command classes
│   │   └── items/        # Graphics items for rungs, instructions, branches
│   ├── engine-server/    # piplc-engine headless server + library
│   ├── model/            # Data model (Program, Rung, Instruction, Variable)
│   │   ├── Decorators/   # Contact decorator classes
│   │   └── Instructions/ # Instruction type classes
│   ├── protocol/         # WebSocket protocol (JSON + binary messages)
│   ├── runtime/          # Execution engine, memory, embedded server, remote contexts
│   └── widgets/          # UI components (SimulationPanel, WatchPanel, etc.)
├── tests/                # Unit and integration tests
├── docs/                 # Documentation
├── examples/             # Example project files
├── installer/            # Windows (NSIS) and Linux (DEB) packaging
├── docker/               # Docker cross-compilation for ARM64
└── .github/workflows/    # CI/CD configuration
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup and guidelines.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Qt Project for the cross-platform framework
- IEC 61131-3 standard for PLC programming language specifications
- The open-source PLC community for inspiration and guidance
